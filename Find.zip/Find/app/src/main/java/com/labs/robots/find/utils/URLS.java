package com.labs.robots.find.utils;

public class URLS {
    private static final String URL_ROOT = "http://79003208229.myjino.ru/api.php?action=";
    public static final String URL_REGISTER = URL_ROOT + "signup";
    public static final String URL_LOGIN= URL_ROOT + "login";
}
